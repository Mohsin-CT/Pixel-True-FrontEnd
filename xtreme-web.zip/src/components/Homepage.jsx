import React from 'react';
import TWCconfig from "../TWCconfig.json";
import xtremewebtecho from "../images/logo.svg";
import HeroImg from "../images/HeroImg.png";
import semicon from "../images/sem-icon.png";
import seoicon from "../images/seo-icon.png";
import roiicon from "../images/roi-icon.png";
import aboutimg from "../images/about-img.jpg";
import whatwedoicon2 from "../images/what-we-do-icon-2.png";
import whatwedoicon3 from "../images/what-we-do-icon-3.png";
import whatwedoicon4 from "../images/what-we-do-icon-4.png";
const Homepage = () => {
  const {HeaderWrapper,
    HeaderContainer,
    HeroConvas,
    MainMenu,
    MainMenuLi,
    HeroContainer,
    HeroSectionRow,
    HeroSectionCol,
    HeroTitle,
    HeroTitleSmall,
    HeroDescription,
    HeroBtn,
    MainContentSection,
    MainContentContainer,
    ContentTitle,
    ContentBoxIcon,
    ContentBoxItem,
    ContentIcon,
    ContentBoxTitle,
    ContentBoxDescription,
    AboutUsRow,
    AboutUsCol,
    AboutUsTitle,
    AboutUsTitleSmall,
    AboutUsH5,
    AboutUsDescription,
    ThemeLightBtn,
    InnerContentBoxRow,
    ContentBoxItem2,
    AboutUsCol3,
    AboutUsRow2,
    AboutUsCol2,
    InnerContentBoxRow2,
    InnerContentBoxRow3,
	}= TWCconfig;
  return ( <div>

    {/* Main Header */}
    <div className={HeaderWrapper}>
      <div className={HeaderContainer}>
        <a href="#"> <img width="250" src={xtremewebtecho} alt="" /> </a>
        <nav>
          <ul className={MainMenu}>
            <li className={MainMenuLi}> <a href="#">Home</a> </li>
            <li className={MainMenuLi}> <a href="#">About Us</a> </li>
            <li className={MainMenuLi}> <a href="#">Services</a> </li>
            <li className={MainMenuLi}> <a href="#">Contact Us</a> </li>
            <li className={MainMenuLi}> <a href="#">Clients</a> </li>
          </ul>
        </nav>
      </div>
    </div>
    {/* Hero Section */}
    <div className={HeroConvas}>
      <div className={HeroContainer}>
        <div className={HeroSectionRow}>
          <div className={HeroSectionCol}>
            <h1 className={HeroTitle}> <small className={HeroTitleSmall}>Digital Solutions</small> You Have Been Looking For</h1>
            <p className={HeroDescription}>One-stop Solution for your online business growth. We are a result-oriented Digital Agency trusted by hundreds of startups. Most importantly, let us create a website or online store for your business.</p>
            <a className={HeroBtn} href="#">Start a Project</a>
          </div>
          <div className={HeroSectionCol}>
            <img src={HeroImg} alt="" />
          </div>
        </div>
      </div>
    </div>

    {/* Site Content Section */}

      <div className={MainContentSection}>
        <div className={MainContentContainer}>
          <h2 className={ContentTitle}>Check what happening inside.</h2>

          {/* Content Box */}
          <div className={ContentBoxIcon}>

            <div className={ContentBoxItem}>
              <img className={ContentIcon} src={semicon} alt="" />
              <h3 className={ContentBoxTitle}>In-Depth Analysis</h3>
              <p className={ContentBoxDescription}>By understanding your requirements, We perform in-depth analysis and then we plan strategy by following the latest trends.</p>
            </div>

            <div className={ContentBoxItem}>
              <img className={ContentIcon} src={seoicon} alt="" />
              <h3 className={ContentBoxTitle}>One-Stop Services</h3>
              <p className={ContentBoxDescription}>For your convenience, we have brought all services under one roof. You no need to blame others as we tool all the responsibilities.</p>
            </div>

            <div className={ContentBoxItem}>
              <img className={ContentIcon} src={roiicon} alt="" />
              <h3 className={ContentBoxTitle}>Result-Oriented Approach</h3>
              <p className={ContentBoxDescription}>Your main concern is with the outcome so we pay attention to it. Our experts know the strategies that can grow any business. We ensure quality delivery.</p>
            </div>

          </div>

          {/* About Us Section */}
          <div className={AboutUsRow}>
            <div className={AboutUsCol}>
              <img src={aboutimg} alt="" />
            </div>
            <div className={AboutUsCol}>
              <h4 className={AboutUsTitle}> <small className={AboutUsTitleSmall}>ABOUT US</small> You are our asset and your business growth is our success!</h4>
              <h5 className={AboutUsH5}>We pay attention to every client needs. Our main focus is on results. However, We create a website or Online Store with special techniques.</h5>
              <p className={AboutUsDescription}>Ordinary business websites are not enough. We designed 400+ websites and we know the needs of your business. Your website Design and Content will make the difference. Our experts will make a noticeable online presence of your business, with the guarantee of more sales and leads. We do clean code because we know, the website should load within a second. In our portfolio, we have more than 100 startups with handsome sales.</p>
              <a className={ThemeLightBtn} href="#">Our Journey</a>
            </div>
          </div>

          {/* About Us Section */}
          <div className={AboutUsRow2}>
              <div className={AboutUsCol3}>
                <h4 className={AboutUsTitle}> <small className={AboutUsTitleSmall}>What we do</small> Increase your business productivity!</h4>

                <p className={AboutUsDescription}>At “Xtreme Web Tech”, we help small, medium and large enterprises to get online visibility. We provide <b>Website Designing, Content Strategy, Marketing, Mobile Apps Development and Search Engine Optimisation.</b> Moreover, this is essential for every business.</p>

                <p className={AboutUsDescription}>We ensure business owners meet their business goals and push through the limitations that exist. We create a website or online store with guaranteed results.</p>

                <a className={ThemeLightBtn} href="#">Explore More</a>
              </div>
              
              <div className={AboutUsCol2}>
                <div className={InnerContentBoxRow2}>
                  <div className={ContentBoxItem2}>
                  <img className={ContentIcon} src={semicon} alt="" />
                  <h3 className={ContentBoxTitle}>Website Designing</h3>
                </div>

                <div className={ContentBoxItem2}>
                  <img className={ContentIcon} src={whatwedoicon3} alt="" />
                  <h3 className={ContentBoxTitle}>Mobile Apps
Development</h3>
                </div>
                </div>

                <div className={InnerContentBoxRow3}>
                  <div className={ContentBoxItem2}>
                  <img className={ContentIcon} src={whatwedoicon2} alt="" />
                  <h3 className={ContentBoxTitle}>Content Strategy & Marketing</h3>
                </div>

                <div className={ContentBoxItem2}>
                  <img className={ContentIcon} src={whatwedoicon4} alt="" />
                  <h3 className={ContentBoxTitle}>Search Engine Optimisation</h3>
                </div>
                </div> 
              </div>
          </div>


        </div>
      </div>    
  </div>
  );
};

export default Homepage;