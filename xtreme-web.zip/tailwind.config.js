module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx,json}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        blue: { 650: "#190758", 550: "#28117a" },
        pink: { 650: "#ff4357", 550: "#e14f5f" },
        gray: {
          250: "#ECEDF4",
          350: "#EEECF2",
          450: "#B9BDC6",
          550: "#CFD3DB",
          650: "#777E90",
          750: "#B1B5C342",
          850: "#0000001F",
        },
        red: { 50: "#EB4E4E" },
        yellow: { 50: "#FF8C211A", 150: "#FF8C21" },
        green: { 50: "#20AC501A", 150: "#1A803D" },
      },

      fontFamily: {
        sans: ["Plus Jakarta Sans", "sans-serif"],
      },
      boxShadow: {
        '3xl': '0px 3px 23.2px 3.8px rgb(0 0 0 / 6%)',
      }
    },
    // fontSize: { "10xl": "2.75rem" },
  },
  plugins: [],
}
