// Home page assetes here
import img3 from "../images/img3.png";

// WritingSample assetes
import writingPipe from "./WritingSamples/WritingPipe.png";
import WritingTools from "./WritingSamples/writingToolIs.png";
import WritingDog from "./WritingSamples/WritingDog.png";
import writingHeroImage from "./WritingSamples/writingHeaderImage.png";

// ActiveTMobile assete
import copyLink from "./ActivateTMobile/copylink.svg";
import facebook from "./ActivateTMobile/facebook.svg";
import skype from "./ActivateTMobile/skype.svg";
import ActiveTMobileHeader from "./ActivateTMobile/ActiveTMobileHeader.png";
import ActivateQuotesStart from "./ActivateTMobile/ActivateQuotesStart.png";
import AtivateQuotesEnd from "./ActivateTMobile/ActivateQuotesEnd.png";
import HowtoActive from "./ActivateTMobile/HowtoActive.png";
import AlreadyActivate from "./ActivateTMobile/AlreadyActivate.png";
import ActivateForFree from "./ActivateTMobile/ActivateForFree.png";
import orangeFacebook from "./ActivateTMobile/orangeFacebook.svg";
import orangeSkype from "./ActivateTMobile/orangeTwitter.svg";
// common Assets
import QuoteLargeStart from "./QuoteLargeEndIcon.png";
import QuoteLargeEnd from "./QuoteLargeStartIcon.png";
import menuopen from "./Common/menuopen.png";
import menuclose from "./Common/menuClose.png";

export const images = {
  // Home page assetes here
  img3,
  // WritingSample assetes
  writingPipe,
  WritingTools,
  WritingDog,
  writingHeroImage,

  // ActiveTMobile assete
  copyLink,
  facebook,
  skype,
  ActivateQuotesStart,
  AtivateQuotesEnd,
  ActiveTMobileHeader,
  HowtoActive,
  AlreadyActivate,
  ActivateForFree,
  orangeFacebook,
  orangeSkype,

  // common Assets
  QuoteLargeStart,
  QuoteLargeEnd,
  menuopen,
  menuclose,
};
