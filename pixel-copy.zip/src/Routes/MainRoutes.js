import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ActivateTMobile from "../pages/ActivateTMobile/ActivateTMobile";
import WritingSample from "../pages/WritingSamples/WritingSample";
import Homepage from "../pages/HomePage/Homepage";
import { AboutUsPage } from "../pages/AboutUs/AboutUsPage";
import Pricing from "../pages/PricingPage/Pricing";

const MainRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/:writingSample" element={<WritingSample />} />
        <Route path="/ActivateTMobile" element={<ActivateTMobile />} />
        <Route path="about-us" element={<AboutUsPage />} />
        <Route path="pricing" element={<Pricing />} />
      </Routes>
    </BrowserRouter>
  );
};

export default MainRoutes;
