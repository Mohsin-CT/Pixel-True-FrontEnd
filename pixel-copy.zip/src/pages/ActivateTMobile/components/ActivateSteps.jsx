import React from "react";
import TWCconfig from "../../../TWCconfig.json";
import ImageAssets from "../../commonComponents/ImageAssets";

const ActivateSteps = () => {
  const { CopywritingSecrets, CopywritingP, CopywritingTitle } = TWCconfig;

  return (
    <div className="flex flex-col px-4 py-10 lg:pl-0 lg:pr-20 lg:py-20 gap-20 ">
      <div className="flex flex-col gap-6">
        <h3 className="text-[32px] lg:text-[48px] leading-[2.5rem] font-[600]  lg:leading-none ">
          Activate Your Phone Online
        </h3>
        <p className="text-[20px] font-[400] text-gray-850">
          On the Metro by T-Mobile website, there’s an Online Activation Tools
          option located under the New Accounts tab. This page will take you
          through the step-by-step instructions to activate your phone and
          create a new Metro by T-Mobile account.
        </p>
        <p className="text-[20px] font-[400] text-gray-850">
          You’ll need to provide personal information such as your name and
          address, as well as the information for the phone you want to
          activate. This includes the ESN or IMEI number, which is usually
          located on a sticker underneath the phone’s battery.
        </p>
      </div>
      <div className="flex flex-col gap-6">
        <h3 className="text-[32px] lg:text-[48px] leading-[2.5rem] font-[600] ">
          Activate by Calling Customer Service
        </h3>
        <p className="text-[20px] font-[400] text-gray-850">
          By calling (888) 8METRO8, on a phone other than the one being
          activated (or deactivated, if you’re activating a new phone on an
          existing line), you can quickly activate your new phone.
        </p>
        <p className="text-[20px] font-[400] text-gray-850">
          The customer service representative will help you with the activation
          process.
        </p>
        <p className="text-[20px] font-[400] text-gray-850">
          Similar to activating online, you’ll need to provide your personal
          information to set up your new account, then the ESN or IMEI number
          for your new phone.
        </p>
      </div>
      <div className="flex flex-col gap-6">
        <h3 className="text-[32px] lg:text-[48px] font-[600] ">
          Activate by Calling 228
        </h3>
        <p className="text-[20px] font-[400] text-gray-850">
          If you don’t have another phone nearby and the phone you’re activating
          is already a Metro device, you can dial 228 to activate it. This
          process is simple and your phone will be unlocked moments after
          hanging up.
        </p>
      </div>
      <div className="flex-col">
        <div className="flex ">
          <h3 className="text-[24px] font-[700]">
            The automated system can handle many different tasks This Includes :
          </h3>
        </div>
        <div className="flex flex-col gap-5 text-[20px] mt-5 text-gray-850 font-[4000]">
          <div className="flex gap-4 items-center">
            <div className="h-4 w-4 rounded-full bg-orange-850 "></div>
            <h3>Activating your phone</h3>
          </div>
          <div className="flex gap-4 items-center">
            <div className="h-4 w-4 rounded-full bg-orange-850 "></div>
            <h3>Taking personal information to start your account</h3>
          </div>
          <div className="flex gap-4 items-center">
            <div className="h-4 w-4 rounded-full bg-orange-850 "></div>
            <h3>Taking payment for your first month’s bill</h3>
          </div>
        </div>
      </div>
      <div className="flex flex-col gap-6">
        <h3 className="text-[32px] lg:text-[48px] leading-[2.5rem] font-[600] ">
          Activate in Person
        </h3>
        <p className="text-[20px] font-[400] text-gray-850">
          If you prefer a personal touch or simply don’t like activating over
          the phone, you can also drop by a MetroPCS store or service center to
          have a sales representative assist you in activating your phone and
          setting up your account.
        </p>
        <p className="text-[20px] font-[400] text-gray-850">
          This option is nice for those who aren’t tech-savvy, or if you need to
          visit the store anyway to purchase your new phone. Since you’re
          already there, you might as well have them handle the process for you!
        </p>
      </div>
    </div>
  );
};

export default ActivateSteps;
