import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import TWCconfig from "../../../TWCconfig.json";
import ImageAsset from "../../commonComponents/ImageAssets";

export default function WritingHeroSection(props) {
  const params = useParams();
  const {
    HeroSectionWrapper,
    HeroSectionContent,
    HeroSectionImg,
    HeroSectionTitle,
    HeroSectionTitleWrap,
    HeroSectionText,
    SeeBtn,
    WritingHeroSectionWrapper,
  } = TWCconfig;
  return (
    <div className={WritingHeroSectionWrapper}>
      <div className="w-full lg:w-[53%] pl-10 lg:pl-[180px]">
        <div className={HeroSectionTitleWrap}>
          <h1 className={HeroSectionTitle}>Writing Samples</h1>
          <p className={HeroSectionText}>
            Want to see what we can do? Review some of the amazing articles
            below that have increased engagement, driven organic traffic, and
            led to increased affiliate/sales conversions.
          </p>
          <a className={SeeBtn} href="#">
            SEE PRICING
          </a>
        </div>
      </div>
      <div className=" w-full lg:w-[47%] flex lg:justify-end justify-center HeroSectionImg-overlay pr-24 pt-10">
        <ImageAsset src="writingHeroImage" />
      </div>
    </div>
  );
}
