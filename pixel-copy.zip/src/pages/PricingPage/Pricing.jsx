import React from "react";
import TWCconfig from "../../TWCconfig.json";
import Footer from "../commonComponents/Footer";
import Header from "../commonComponents/Header";
import PricingTable from "../commonComponents/PricingTable";
import AddOns from "../HomePage/components/AddOns";
import ChooseAddOns from "./components/ChooseAddOns";

const Pricing = () => {
  const {
    PricingTitleBar,
    PricingTitleBarInner,
    PricingTitle,
    PricingText,
    TableDescription,
    TableDescriptionInner,
    TableDescriptionText
  } = TWCconfig;

  return (
    <div>
      <Header />
      <div className={PricingTitleBar}>
        <div className={PricingTitleBarInner}>
            <h1 className={PricingTitle}>Pick a Plan that’s <span className="font-bold text-orange-850">Right for you!</span> </h1>
            <p className={PricingText}>No matter how much content you need, we have a plan to fit your budget. Our comprehensive <br /> service goes beyond just writing copy, we make sure that your project is completed from <br /> start to finish without issue.</p>
        </div>
        <PricingTable />
      </div>

      <div className={TableDescription}>
        <div className={TableDescriptionInner}>
            <p className={TableDescriptionText}>Why do we have a minimum of 8,000 words? Well we want you to see value out of our writing and if you're not <br /> posting at least two articles per week, the current search engine algorithms won't bother to reward your site. <br /> So in order for us to drive value for you, we need to write a minimum of 8 articles a month.</p>
        </div>
      </div>
      <ChooseAddOns />
      <Footer />
    </div>
  );
};

export default Pricing;