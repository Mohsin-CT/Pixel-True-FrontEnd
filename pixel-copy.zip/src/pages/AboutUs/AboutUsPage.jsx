import React from "react";
import TWCconfig from "../../TWCconfig.json";
import img4 from "../../images/img4.png";
import SliderView from "../../images/SliderView.png";

import GrahamIcon from "../../images/Graham.png";
import PatrickIcon from "../../images/patrick.png";
import warrenIcon from "../../images/warren.png";
import QuoteLargeEndIcon from "../../images/QuoteLargeEndIcon.png";
import QuoteLargeStartIcon from "../../images/QuoteLargeStartIcon.png";
import Header from "../commonComponents/Header";
import HeroAboutus from "./components/HeroAboutus";
import Section4Aboutus from "./components/Section4Aboutus";
import Section3 from "./components/Section3Aboutus";
import OurMissionAboutus from "./components/OurMissionAboutus";
import AboutusTags from "./components/AboutusTags";
import Footer from "../commonComponents/Footer";
import CopywritingForm from "../HomePage/components/CopywritingForm";
import SideContentBox from "../commonComponents/SideContentBox";
import BookCall from "../commonComponents/BookCallSection";

export const AboutUsPage = () => {
  const {
    Section4AboutusContainer,
    SimpleTextBlockTitle2,
    LightTextSection4Aboutus,
    Section4AboutusText,
    Section4AboutusConnectTitle,
    ContactBtn,
    ViewMoreBtn,
    SimpleTextBlock6,
    CopywritingTitle2,
    LightBlockSection4Aboutus,
    LightBlockSection4Aboutus2,
    BookCallSection4,
    SimpleTextBlock2,
    SimpleTextBlockTitle3,
    LightSimpleTextBlock5,
    SimpleTextBlockTitle6,
    SimpleTextBlockText6,
    SliderContainer,
    CopywritingSecrets2,
    CopywritingTitle4,
    CopywritingP,
  } = TWCconfig;
  return (
    <div>
      <Header />
      <HeroAboutus />
      <OurMissionAboutus />
      <Section3 />
      <div className=" w-full flex ">
        <div className="w-[50%]">
          <div className={`${Section4AboutusContainer} `}>
            <div className={`${LightTextSection4Aboutus} `}>
              <h2 className={SimpleTextBlockTitle2}>
                We Provide The <br /> Services You <br /> Need
              </h2>
              <p className={Section4AboutusText}>
                We don't just write content. We can create <br /> sales copy,
                landing pages, researched e- <br /> books and more.
              </p>
            </div>
            <a href="#" className={ViewMoreBtn}>
              View More
            </a>
          </div>
        </div>
        <div className="w-[50%] bg-[#ffeee3] relative">
          <Section4Aboutus />
        </div>
      </div>

      <div className="w-full items-start">
        <div className={LightBlockSection4Aboutus2}>
          <div className={`${BookCallSection4}`}>
            <h4 className={Section4AboutusConnectTitle}>
              Connect with us to learn <br /> more about the services.
            </h4>
            <a className={ContactBtn} href="#">
              CONTACT US
            </a>
          </div>
        </div>
      </div>
      {/* membership benefits... */}

      <div className="w-full bg-blue-200">
        <div className={SimpleTextBlock6}>
          <div className="flex flex-wrap">
            <div className="w-[50%]">
              <img
                className="max-w-[790px] -ml-[140px] -mt-[53px]"
                src={img4}
                alt=""
              />
            </div>
            <div className="w-[50%]">
              <h2 className={CopywritingTitle2}>Membership Benefits</h2>
              <SideContentBox />
            </div>
          </div>
        </div>
      </div>
      {/* book a call... */}
      <div className="w-full">
        <div className={LightBlockSection4Aboutus}>
          <BookCall />
        </div>
      </div>
      <div className="w-full">
        <div className={SimpleTextBlock2}>
          <h2 className={SimpleTextBlockTitle3}>Our Passionate Team</h2>
          <p className={SimpleTextBlockText6}>
            We only hire experienced writers from the U.S. to ensure that your{" "}
            <br /> copy fits with your audience.
          </p>
          {/* <AboutusTags/> */}
          <div className="relative">
            <div className="flex self-center py-[90px]  space-x-[152px] relative">
              <img
                src={QuoteLargeEndIcon}
                alt=""
                className="absolute bottom-[0rem] left-[-9rem]"
              />
              <img
                src={QuoteLargeStartIcon}
                alt=""
                className="absolute top-0 right-[-24rem]"
              />

              <div className="flex flex-col">
                <img src={GrahamIcon} alt="" />
                <p className="pt-[28px] text-[24px] font-bold">Graham</p>
                <p>CEO</p>
              </div>
              <div className="flex flex-col">
                <img src={PatrickIcon} alt="" />
                <p className="pt-[42px] text-[24px] font-bold">Patrick</p>
                <p>Director - Content & Planning</p>
              </div>
              <div className="flex flex-col">
                <img src={warrenIcon} alt="" />
                <p className="pt-[28px] text-[24px] font-bold">Warren</p>
                <p>CMO</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="w-full bg-blue-200">
        <div className={SimpleTextBlock2}>
          <h2 className={SimpleTextBlockTitle3}>Our Partners</h2>
          <AboutusTags />
        </div>
      </div>
      <div className="w-full -mb-48">
        <div className={LightSimpleTextBlock5}>
          <h2 className={SimpleTextBlockTitle6}>What’s Our Client Say</h2>
          <p className={SimpleTextBlockText6}>
            Our clients tell the true story of how we can help <br /> drive
            results through copy
          </p>
          <div className={SliderContainer}>
            <img src={SliderView} alt="" />
          </div>
        </div>
      </div>
      <div className={`${CopywritingSecrets2} bg-[#fce6dc] `}>
        <div className="w-1/2  self-center">
          <h2 className={`${CopywritingTitle4}`}>
            Inspired by what you <br /> see?{" "}
            <span className="text-orange-850">
              Let’s Talk About <br /> Your Project.
            </span>
          </h2>
          <p className={CopywritingP}>
            Sign up for contact and receive a series of invaluable copywriting{" "}
            <br /> tips that are sure to improve your SEO and increase organic{" "}
            <br /> traffic.
          </p>
        </div>
        <div className="w-1/2">
          <CopywritingForm />
        </div>
      </div>
      <Footer />
    </div>
  );
};
