import React from "react";
import TWCconfig from "../../../TWCconfig.json";
import OurMissionImg from "../../../images/OurMissionImg.png";

export default function OurMissionAboutus(props) {
  const {
    HeroSectionWrapper,
    OurMissionSectionContent,
    OurMissionSectionImg,
    Section3AboutusTitle,
    HeroSectionTitle,
    HeroSectionTitleWrap,
    HeroSectionText,
  } = TWCconfig;
  return (
    <div className={HeroSectionWrapper}>
      <div className={OurMissionSectionContent}>
        <div className={HeroSectionTitleWrap}>
          <h1 className={Section3AboutusTitle}>
            It is our Mission to Help you Grow your Business
          </h1>
          <p className={HeroSectionText}>
            We produce high quality content with your goals in mind. No matter
            whether you're looking to educate, promote or convert, we've got the
            U.S. writers for your content. Our writers are skilled at taking
            your topic and breaking it down into keyword optimized articles that
            will drive results for your business.
          </p>
        </div>
      </div>
      <div className={OurMissionSectionImg}>
        <img className="w-[50%]" src={OurMissionImg} alt="" />
      </div>
    </div>
  );
}
