import React, { useState, useEffect } from "react";
import TWCconfig from "../../../TWCconfig.json";
import HeroAboutusImg from "../../../images/HeroAboutusImg.png";

export default function HeroAboutus(props) {
  const {
    HeroSectionWrapper,
    HeroAboutusContent,
    HeroSectionImg,
    HeroSectionTitle,
    HeroSectionTitleWrap,
    HeroSectionText,
    HeroAboutusImgClass,
    SeeBtn,
    BookACallBtn,
  } = TWCconfig;
  return (
    <div className={HeroSectionWrapper}>
      <div className={HeroAboutusImgClass}>
        <img className="w-[47%]" src={HeroAboutusImg} alt="" />
      </div>
      <div className={HeroAboutusContent}>
        <div className={HeroSectionTitleWrap}>
          <h1 className={HeroSectionTitle}>
            We're a Copywriting Team that actually{" "}
            <b className="font-bold text-orange-850">
              Walk the walk and Talk the Talk.
            </b>{" "}
          </h1>
          <p className={HeroSectionText}>
            As content site owners ourselves, we know what it takes <br /> to
            drive organic traffic by using high quality, and <br /> optimized
            content.{" "}
          </p>
          <a className={BookACallBtn} href="#">
            Book a Call
          </a>
          <a className={SeeBtn} href="#">
            SEE PRICING
          </a>
        </div>
      </div>
    </div>
  );
}
