import React, { useState, useEffect } from "react";
import TWCconfig from "../../../TWCconfig.json";
import BookIcon from "../../../images/BookSection4Aboutus.svg";

export default function Section4Aboutus(props) {
  const {
    LightContentBoxWrap,
    LightContentBoxItem,
    LightContentBoxItemTitle,
    LightContentBoxItemText,
    ContentIconBox,
    Section4CardText,
  } = TWCconfig;
  return (
    <div className={""}>
      <div className="flex absolute top-[9.5rem] right-[20rem] w-full">
        <div className="flex flex-col bg-white shadow-md rounded-[10px] p-6 w-[100%] mx-[24px]">
          <img
            src={BookIcon}
            className="flex self-center w-[110px] pt-[52px]"
            alt=""
          />
          <p className="text-[24px] font-poppin-bold mb-[20px] leading-[24px] tracking-[-0.6px] mt-[42px] self-center">
            Sales Copy
          </p>
          <p className={Section4CardText}>
            High quality, converting sales copy that will get you new business
          </p>
        </div>
        <div className="flex flex-col bg-white shadow-md rounded-[10px] p-6 w-[100%] mx-[24px]">
          <img
            src={BookIcon}
            className="flex self-center w-[110px] pt-[52px]"
            alt=""
          />
          <p className="text-[24px] font-poppin-bold mb-[20px] leading-[24px] tracking-[-0.6px] mt-[42px] self-center">
            Landing Pages
          </p>
          <p className={Section4CardText}>
            High quality, converting sales copy that will get you new business
          </p>
        </div>
        <div className="flex flex-col bg-white shadow-md rounded-[10px] p-6 w-[100%] mx-[24px]">
          <img
            src={BookIcon}
            className="flex self-center w-[110px] pt-[52px]"
            alt=""
          />
          <p className="text-[24px] font-poppin-bold mb-[20px] leading-[24px] tracking-[-0.6px] mt-[42px] self-center">
            E-Books
          </p>
          <p className={Section4CardText}>
            High quality, converting sales copy that will get you new business
          </p>
        </div>
      </div>
    </div>
  );
}
